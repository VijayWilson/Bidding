use master;
go

if exists(select * from sys.databases where name = 'Bidding')
begin
	drop database Bidding;
end
go

create database Bidding;
go

use Bidding;
go

if OBJECT_ID('dbo.User') is not null
begin
	drop table [User];
end
go

create table [User] (
	Id int not null identity(1,1),
	UserName nvarchar(max) not null,
	Email nvarchar(255) not null,
	[Password] nvarchar(max) not null
);

alter table [User] add constraint PK_User primary key (Id);
alter table [User] add constraint Uk_User_Email unique(Email);
go


if OBJECT_ID('dbo.AuctionItem') is not null
begin
	drop table [AuctionItem];
end
go

create table [AuctionItem] (
	Id int not null identity(1,1),
	UserId int not null,
	Title nvarchar(max) not null,
	[Description] nvarchar(max) null,
	StartingPrice float not null default 0,
	EndDate datetime not null
);

alter table [AuctionItem] add constraint PK_AuctionItem primary key (Id);
alter table [AuctionItem] add constraint FK_AuctionItem_User foreign key (UserId) references [User](Id);
go

if OBJECT_ID('dbo.Bid') is not null
begin
	drop table Bid;
end
go

create table [Bid] (
	Id int not null identity(1,1),
	AuctionItemId int not null,
	UserId int not null,
	Price float not null default 0
);

alter table [Bid] add constraint PK_Bid primary key (Id);
alter table [Bid] add constraint FK_Bid_AuctionItem foreign key (AuctionItemId) references [AuctionItem](Id);
alter table [Bid] add constraint FK_Bid_User foreign key (UserId) references [User](Id);
go