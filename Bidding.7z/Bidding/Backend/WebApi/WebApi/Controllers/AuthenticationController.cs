﻿namespace WebApi.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using WebApi.Processors;
    using WebApi.Requests;

    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthenticationProcessor _authenticationProcessor;

        public AuthenticationController(IAuthenticationProcessor authenticationProcessor)
        {
            _authenticationProcessor = authenticationProcessor;
        }

        [HttpPost]
        public IActionResult Authenticate(AuthenticationRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(_authenticationProcessor.AuthenticateUser(request));
        }
    }
}
