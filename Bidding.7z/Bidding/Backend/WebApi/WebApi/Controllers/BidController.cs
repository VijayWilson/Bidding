﻿namespace WebApi.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using WebApi.Processors;
    using WebApi.Requests;

    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BidController : ControllerBase
    {
        private readonly IBidProcessor _bidProcessor;

        public BidController(IBidProcessor bidProcessor)
        {
            _bidProcessor = bidProcessor;
        }

        [HttpPost]
        public IActionResult CreateBid([FromBody] CreateBidRequest request)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var bidId = _bidProcessor.CreateBid(request);
            return Ok(bidId);
        }

        [HttpGet("{auctionItemId}")]
        public IActionResult GetBidsHistory(int auctionItemId)
        {
            var bids = _bidProcessor.GetBidsHistory(auctionItemId);
            return Ok(bids);
        }
    }
}
