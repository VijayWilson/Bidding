﻿namespace WebApi.Controllers
{
    using AutoMapper;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.JsonPatch;
    using Microsoft.AspNetCore.Mvc;
    using WebApi.Processors;
    using WebApi.Requests;

    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AuctionItemController : ControllerBase
    {
        private readonly IAuctionItemProcessor _auctionItemProcessor;
        private readonly IMapper _mapper;

        public AuctionItemController(IAuctionItemProcessor auctionItemProcessor, IMapper mapper)
        {
            _auctionItemProcessor = auctionItemProcessor;
            _mapper = mapper;
        }

        [HttpPost]
        public IActionResult CreateAuctionItem(CreateAuctionItemRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Created("Auction Item Created", _auctionItemProcessor.CreateAuctionItem(request));
        }

        [HttpGet("all")]
        public IActionResult GetAllAuctionItemsUser()
        {
            return Ok(_auctionItemProcessor.GetAllAuctionItemsOfUser());
        }

        [HttpGet("others")]
        public IActionResult GetAllAuctionItemsOthers()
        {
            return Ok(_auctionItemProcessor.GetAllAuctionItemsOfOthers());
        }

        [HttpGet("{id}")]
        public IActionResult GetAuctionItem(int id)
        {
            return Ok(_auctionItemProcessor.GetAuctionItem(id));
        }

        [HttpPatch("{id}")]
        public IActionResult PatchAuctionItem(int id, [FromBody] JsonPatchDocument<UpdateAuctionItemRequest> patchDocument)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var patchItemRequest = _mapper.Map<UpdateAuctionItemRequest>(_auctionItemProcessor.GetAuctionItem(id));
            patchDocument.ApplyTo(patchItemRequest);

            if(!TryValidateModel(patchItemRequest))
                return BadRequest(ModelState);

            return Ok(_auctionItemProcessor.UpdateAuctionItem(id, patchItemRequest));
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteAuctionItem(int id)
        {
            return Ok(_auctionItemProcessor.DeleteAuctionItem(id));
        }
    }
}
