﻿namespace WebApi.Requests
{
    using System.ComponentModel.DataAnnotations;

    public class CreateBidRequest
    {
        [Required]
        public int AuctionItemId { get; set; }

        [Required]
        public double Price { get; set; }
    }
}
