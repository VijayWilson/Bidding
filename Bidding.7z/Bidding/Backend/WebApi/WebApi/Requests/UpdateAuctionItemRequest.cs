﻿namespace WebApi.Requests
{
    using System.ComponentModel.DataAnnotations;
    using WebApi.Attributes;

    public class UpdateAuctionItemRequest
    {
        [Required]
        public string Title { get; set; }
        public string? Description { get; set; }

        [Required]
        public double StartingPrice { get; set; }

        [Required]
        [FutureDate]
        public DateTime? EndDate { get; set; }
    }
}
