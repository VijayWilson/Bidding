﻿namespace WebApi.Mapper
{
    using AutoMapper;
    using DataAccessLayer.Models;
    using WebApi.Requests;
    using WebApi.Responses;

    public class BidMapperProfile : Profile
    {
        public BidMapperProfile()
        {
            CreateMap<CreateBidRequest, Bid>();

            CreateMap<Bid, GetBidResponse>().
                ForMember(x => x.UserName, opt => opt.MapFrom(s => s.User.UserName));
        }
    }
}
