﻿namespace WebApi.Mapper
{
    using AutoMapper;
    using DataAccessLayer.Models;
    using WebApi.DTO;
    using WebApi.Requests;
    using WebApi.Responses;

    public class UserMapperProfile: Profile
    {
        public UserMapperProfile()
        {
            CreateMap<AuthenticationRequest, User>();

            CreateMap<User, AuthUser>();

            CreateMap<CreateUserRequest, User>();

            CreateMap<User, CreateUserResponse>();
        }
    }
}
