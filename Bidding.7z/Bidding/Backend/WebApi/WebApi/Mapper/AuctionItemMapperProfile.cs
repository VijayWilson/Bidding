﻿namespace WebApi.Mapper
{
    using AutoMapper;
    using DataAccessLayer.Models;
    using WebApi.Requests;
    using WebApi.Responses;

    public class AuctionItemMapperProfile : Profile
    {
        public AuctionItemMapperProfile()
        {
            CreateMap<CreateAuctionItemRequest, AuctionItem>();

            CreateMap<GetAuctionItemResponse, UpdateAuctionItemRequest>();

            CreateMap<UpdateAuctionItemRequest, AuctionItem>();

            CreateMap<AuctionItem, CreateOrUpdateAuctionItemResponse>();

            CreateMap<AuctionItem, GetAuctionItemResponse>()
                .ForMember(d => d.HighestPrice, opt => opt.MapFrom(s => GetPrice(s.Bids.FirstOrDefault())));
        }

        public double GetPrice(Bid bid)
        {
            return bid?.Price ?? 0;
        }
    }
}
