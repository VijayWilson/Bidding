﻿namespace WebApi.Responses
{
    public class CreateOrUpdateAuctionItemResponse
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string? Description { get; set; }
        public double StartingPrice { get; set; }
        public DateTime EndDate { get; set; }
    }
}
