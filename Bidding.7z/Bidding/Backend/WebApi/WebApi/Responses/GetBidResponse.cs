﻿namespace WebApi.Responses
{
    public class GetBidResponse
    {
        public int Id { get; set; }
        public int AuctionItemId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public double Price { get; set; }
    }
}
