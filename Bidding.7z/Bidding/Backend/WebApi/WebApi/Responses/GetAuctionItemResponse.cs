﻿namespace WebApi.Responses
{
    public class GetAuctionItemResponse
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string? Description { get; set; }
        public double StartingPrice { get; set; }
        public double HighestPrice { get; set; }
        public DateTime EndDate { get; set; }
    }
}
