﻿namespace WebApi.Responses
{
    public class CreateUserResponse
    {
        public string UserName { get; set; }
        public string Email { get; set; }
    }
}
