﻿namespace WebApi.Filters
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using WebApi.Exceptions;

    public class RestApiExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            var exception = context.Exception;
            var statusCode = StatusCodes.Status500InternalServerError;
            var message = "An unexpected error occurred. Please try again later.";

            if (exception is AuthenticationFailedException)
            {
                message = "Unauthorized";
                statusCode = StatusCodes.Status401Unauthorized;
            }
            else if (exception is NotCreatedException)
            {
                message = "Not created";
                statusCode = StatusCodes.Status400BadRequest;
            }
            else if (exception is NotFoundException)
            {
                message = "Not found";
                statusCode = StatusCodes.Status404NotFound;
            }
            else if (exception is ConflictException)
            {
                message = "Conflict";
                statusCode = StatusCodes.Status409Conflict;
            }
            else if (exception is InvalidDataException)
            {
                message = "Bad request";
                statusCode = StatusCodes.Status400BadRequest;
            }

            context.Result = new ObjectResult(new
            {
                message = message,
                error = context.Exception.Message 
            })
            {
                StatusCode = statusCode
            };

            context.ExceptionHandled = true;
        }
    }
}
