namespace WebApi
{
    using DataAccessLayer.DbContext;
    using DataAccessLayer.Repositories;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.IdentityModel.Tokens;
    using Microsoft.OpenApi.Models;
    using System.Text;
    using WebApi.Filters;
    using WebApi.Mapper;
    using WebApi.Processors;
    using WebApi.Utils;

    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers(options =>
            {
                options.Filters.Add<RestApiExceptionFilter>();
            })
                .AddNewtonsoftJson();

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            
            ConfigureSwaggerServices(builder.Services);

            ConfigureServices(builder.Services, builder.Configuration);

            var app = builder.Build();


            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthentication();
            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }

        private static void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<BiddingDbContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
            });

            services.AddAutoMapper(config => config.AddProfiles([
                    new UserMapperProfile(),
                    new AuctionItemMapperProfile(),
                    new BidMapperProfile(),
                ]));

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = TokenManager.Issuer,
                    ValidAudience = TokenManager.Audience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(TokenManager.SecretKey))
                };
            });

            services.AddAuthorization();

            services.AddHttpContextAccessor();

            services.AddTransient<IClaimReader, ClaimReader>();
            services.AddTransient<IUserDbRepository, UserDbRepository>();
            services.AddTransient<ICryptoManager, CryptoManager>();
            services.AddTransient<ITokenManager, TokenManager>();
            services.AddTransient<IUserProcessor, UserProcessor>();
            services.AddTransient<IAuthenticationProcessor, AuthenticationProcessor>();
            services.AddTransient<IAuctionItemDbRepository, AuctionItemDbRepository>();
            services.AddTransient<IAuctionItemProcessor, AuctionItemProcessor>();
            services.AddTransient<IBidDbRepository, BidDbRepository>();
            services.AddTransient<IBidProcessor, BidProcessor>();
        }

        private static void ConfigureSwaggerServices(IServiceCollection services)
        {
            // Add Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Bidding API", Version = "v1" });

                // Add JWT Authentication
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please enter a valid token",
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] {}
                    }
                });
            });
        }
    }
}
