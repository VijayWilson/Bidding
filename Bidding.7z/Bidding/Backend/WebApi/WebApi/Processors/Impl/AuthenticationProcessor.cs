﻿namespace WebApi.Processors
{
    using AutoMapper;
    using DataAccessLayer.Models;
    using DataAccessLayer.Repositories;
    using WebApi.DTO;
    using WebApi.Exceptions;
    using WebApi.Requests;
    using WebApi.Utils;

    public class AuthenticationProcessor : IAuthenticationProcessor
    {
        private readonly IUserDbRepository _userDbRepository;
        private readonly IMapper _mapper;
        private readonly ITokenManager _tokenManager;
        private readonly ICryptoManager _cryptoManager;

        public AuthenticationProcessor(IUserDbRepository userDbRepository, IMapper mapper, ITokenManager tokenManager, ICryptoManager cryptoManager)
        {
            _userDbRepository = userDbRepository;
            _mapper = mapper;
            _tokenManager = tokenManager;
            _cryptoManager = cryptoManager;
        }

        public string AuthenticateUser(AuthenticationRequest request)
        {
            request.Password = _cryptoManager.CreateHash(request.Password);

            var user = _userDbRepository.Get(_mapper.Map<User>(request));

            if (user == null)
            {
                throw new AuthenticationFailedException("Invalid user data");
            }

            return _tokenManager.GenerateToken(_mapper.Map<AuthUser>(user));
        }
    }
}
