﻿namespace WebApi.Processors
{
    using AutoMapper;
    using DataAccessLayer.Models;
    using DataAccessLayer.Repositories;
    using Microsoft.Data.SqlClient;
    using Microsoft.EntityFrameworkCore;
    using WebApi.Exceptions;
    using WebApi.Requests;
    using WebApi.Responses;
    using WebApi.Utils;

    public class UserProcessor : IUserProcessor
    {
        private readonly IUserDbRepository _userRepository;
        private readonly IMapper _mapper;
        private readonly ICryptoManager _cryptoManager;

        public UserProcessor(IUserDbRepository userRepository, IMapper mapper, ICryptoManager cryptoManager)
        {
            _userRepository = userRepository;
            _mapper = mapper;
            _cryptoManager = cryptoManager;
        }

        public CreateUserResponse CreateUser(CreateUserRequest request)
        {
            request.Password = _cryptoManager.CreateHash(request.Password);
            try
            {
                var user = _userRepository.Add(_mapper.Map<User>(request));

                if (user == null)
                {
                    throw new NotCreatedException("User not created");
                }

                return _mapper.Map<CreateUserResponse>(user);
            }
            catch (DbUpdateException ex) when (ex.InnerException is SqlException sqlEx && sqlEx.Number == 2627)
            {
                throw new ConflictException("Email is already in use.");
            }
        }
    }
}
