﻿namespace WebApi.Processors
{
    using AutoMapper;
    using DataAccessLayer.Models;
    using DataAccessLayer.Repositories;
    using System.Collections.Generic;
    using WebApi.Exceptions;
    using WebApi.Requests;
    using WebApi.Responses;
    using WebApi.Utils;

    public class BidProcessor : IBidProcessor
    {
        private readonly IBidDbRepository _bidDbRepository;
        private readonly IMapper _mapper;
        private readonly IClaimReader _claimReader;
        private readonly IAuctionItemDbRepository _auctionItemDbRepository;

        public BidProcessor(IBidDbRepository bidDbRepository, IMapper mapper, IClaimReader claimReader, IAuctionItemDbRepository auctionItemDbRepository)
        {
            _bidDbRepository = bidDbRepository;
            _mapper = mapper;
            _claimReader = claimReader;
            _auctionItemDbRepository = auctionItemDbRepository;
        }

        public int CreateBid(CreateBidRequest request)
        {
            var auctionItem = _auctionItemDbRepository.Get(request.AuctionItemId);

            if (auctionItem.EndDate <= DateTime.UtcNow)
            {
                throw new InvalidDataException("Auction is already closed");
            }

            if (auctionItem.StartingPrice >= request.Price)
            {
                throw new InvalidDataException("Price is too low");
            }

            var bid = _mapper.Map<Bid>(request);

            bid.UserId = _claimReader.UserId;

            var result = _bidDbRepository.Add(bid);

            if(result == null)
            {
                throw new NotCreatedException("Bid not created");
            }

            return result.Id;
        }

        public IEnumerable<GetBidResponse> GetBidsHistory(int auctionItemId)
        {
            var bids = _bidDbRepository.GetBids(auctionItemId);

            return _mapper.Map<IEnumerable<GetBidResponse>>(bids);
        }
    }
}
