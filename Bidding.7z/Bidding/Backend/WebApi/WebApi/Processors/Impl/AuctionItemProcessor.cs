﻿namespace WebApi.Processors
{
    using AutoMapper;
    using DataAccessLayer.Models;
    using DataAccessLayer.Repositories;
    using WebApi.Exceptions;
    using WebApi.Requests;
    using WebApi.Responses;
    using WebApi.Utils;

    public class AuctionItemProcessor : IAuctionItemProcessor
    {
        private readonly IAuctionItemDbRepository _auctionItemRepository;
        private readonly IClaimReader _claimReader;
        private readonly IMapper _mapper;

        public AuctionItemProcessor(IAuctionItemDbRepository auctionItemRepository, IClaimReader claimReader, IMapper mapper)
        {
            _auctionItemRepository = auctionItemRepository;
            _claimReader = claimReader;
            _mapper = mapper;
        }

        public CreateOrUpdateAuctionItemResponse CreateAuctionItem(CreateAuctionItemRequest request)
        {
            var auctionItem = _mapper.Map<AuctionItem>(request);
            auctionItem.UserId = _claimReader.UserId;
            auctionItem.EndDate = auctionItem.EndDate.ToUniversalTime();

            var result = _auctionItemRepository.Add(auctionItem);

            if (result == null)
            {
                throw new NotCreatedException("Auction item not created");
            }
            
            return _mapper.Map<CreateOrUpdateAuctionItemResponse>(result);
        }

        public IEnumerable<GetAuctionItemResponse> GetAllAuctionItemsOfUser()
        {
            var result = _auctionItemRepository.GetAllItemsOfUser(_claimReader.UserId);

            return _mapper.Map<IEnumerable<GetAuctionItemResponse>>(result);
        }

        public IEnumerable<GetAuctionItemResponse> GetAllAuctionItemsOfOthers()
        {
            var result = _auctionItemRepository.GetAllItemsOfOthers(_claimReader.UserId);

            return _mapper.Map<IEnumerable<GetAuctionItemResponse>>(result);
        }

        public GetAuctionItemResponse GetAuctionItem(int id)
        {
            var result = _auctionItemRepository.Get(id);

            if (result == null)
            {
                throw new NotFoundException("Auction item not found");
            }

            return _mapper.Map<GetAuctionItemResponse>(result);
        }

        public CreateOrUpdateAuctionItemResponse UpdateAuctionItem(int id, UpdateAuctionItemRequest request)
        {
            var auctionItem = _mapper.Map<AuctionItem>(request);

            auctionItem.Id = id;

            auctionItem.UserId = _claimReader.UserId;

            var result = _auctionItemRepository.Update(auctionItem);
            
            if (result == null)
            {
                throw new NotUpdatedException("Auction item not updated");
            }

            return _mapper.Map<CreateOrUpdateAuctionItemResponse>(result);
        }

        public bool DeleteAuctionItem(int id)
        {
            var result = _auctionItemRepository.Delete(id, _claimReader.UserId);

            if (result == null)
            {
                throw new NotDeletedException("Auction item not deleted");
            }

            return true;
        }
    }
}
