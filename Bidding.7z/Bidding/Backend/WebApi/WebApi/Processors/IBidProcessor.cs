﻿namespace WebApi.Processors
{
    using WebApi.Requests;
    using WebApi.Responses;

    public interface IBidProcessor
    {
        int CreateBid(CreateBidRequest request);

        IEnumerable<GetBidResponse> GetBidsHistory(int auctionItemId);
    }
}
