﻿namespace WebApi.Processors
{
    using WebApi.Requests;
    using WebApi.Responses;

    public interface IUserProcessor
    {
        CreateUserResponse CreateUser(CreateUserRequest request);
    }
}
