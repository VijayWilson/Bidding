﻿namespace WebApi.Processors
{
    using WebApi.Requests;
    using WebApi.Responses;

    public interface IAuctionItemProcessor
    {
        CreateOrUpdateAuctionItemResponse CreateAuctionItem(CreateAuctionItemRequest request);

        IEnumerable<GetAuctionItemResponse> GetAllAuctionItemsOfUser();

        IEnumerable<GetAuctionItemResponse> GetAllAuctionItemsOfOthers();

        GetAuctionItemResponse GetAuctionItem(int id);

        CreateOrUpdateAuctionItemResponse UpdateAuctionItem(int id, UpdateAuctionItemRequest request);

        bool DeleteAuctionItem(int id);
    }
}
