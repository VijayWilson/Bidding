﻿namespace WebApi.Processors
{
    using WebApi.Requests;

    public interface IAuthenticationProcessor
    {
        string AuthenticateUser(AuthenticationRequest request);
    }
}
