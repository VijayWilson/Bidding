﻿namespace WebApi.Utils
{
    using WebApi.DTO;

    public interface ITokenManager
    {
        string GenerateToken(AuthUser user);
    }
}
