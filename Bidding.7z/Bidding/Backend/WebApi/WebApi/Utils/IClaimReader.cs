﻿namespace WebApi.Utils
{
    public interface IClaimReader
    {
        int UserId { get; }
    }
}
