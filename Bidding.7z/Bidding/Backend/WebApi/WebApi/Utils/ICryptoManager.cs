﻿namespace WebApi.Utils
{
    public interface ICryptoManager
    {
        public string CreateHash(string input);
    }
}
