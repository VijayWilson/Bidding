﻿namespace WebApi.Utils
{
    public class ClaimReader : IClaimReader
    {
        public readonly HttpContext _httpContext;

        public ClaimReader(IHttpContextAccessor httpContextAccessor)
        {
            _httpContext= httpContextAccessor.HttpContext;
        }

        public int UserId => GetUserId();

        private int GetUserId()
        {
            var userId = _httpContext.User.Claims.FirstOrDefault(c => c.Type == "UserId")?.Value;
            return userId == null ? 0 : int.Parse(userId);
        }
    }
}
