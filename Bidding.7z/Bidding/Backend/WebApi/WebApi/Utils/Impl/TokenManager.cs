﻿namespace WebApi.Utils
{
    using Microsoft.IdentityModel.Tokens;
    using System.IdentityModel.Tokens.Jwt;
    using System.Security.Claims;
    using System.Text;
    using WebApi.DTO;

    public class TokenManager : ITokenManager
    {
        public const string SecretKey = "H2AAeFyvbwdWkelaJLm32cDx8YnvtVgvfJ13canO+98=";
        public const string Issuer = "bidding-admin";
        public const string Audience = "bidding-audience";
        private const int TokenExpiryInMinutes = 30;

        public string GenerateToken(AuthUser user)
        {
            var claims = new[]
                {
                    new Claim("UserId", user.Id.ToString()),
                    new Claim("UserName", user.UserName),
                    new Claim("Email", user.Email)
                };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: Issuer,
                audience: Audience,
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
