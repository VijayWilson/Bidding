﻿namespace WebApi.Exceptions
{
    public class NotCreatedException : Exception
    {
        public NotCreatedException(string message) : base(message)
        {
        }
    }
}