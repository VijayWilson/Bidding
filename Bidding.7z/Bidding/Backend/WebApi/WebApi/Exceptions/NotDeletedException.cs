﻿namespace WebApi.Exceptions
{
    public class NotDeletedException : Exception
    {
        public NotDeletedException(string message) : base(message)
        {
        }
    }
}