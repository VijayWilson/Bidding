﻿namespace WebApi.Exceptions
{
    public class NotUpdatedException : Exception
    {
        public NotUpdatedException(string? message) : base(message)
        {
        }
    }
}