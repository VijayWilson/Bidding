﻿namespace DataAccessLayer.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class AuctionItem
    {
        [Key]
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Title { get; set; }
        public string? Description { get; set; }
        public double StartingPrice { get; set; }
        public DateTime EndDate { get; set; }

        public User User { get; set; }

        public ICollection<Bid> Bids { get; set; }
    }
}
