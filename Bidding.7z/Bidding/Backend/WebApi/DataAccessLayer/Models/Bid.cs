﻿namespace DataAccessLayer.Models
{

    using System.ComponentModel.DataAnnotations;
    public class Bid
    {
        [Key]
        public int Id { get; set; }
        public int UserId { get; set; }
        public int AuctionItemId { get; set; }
        public double Price { get; set; }

        public User User { get; set; }

        public AuctionItem AuctionItem { get; set; }
    }
}
