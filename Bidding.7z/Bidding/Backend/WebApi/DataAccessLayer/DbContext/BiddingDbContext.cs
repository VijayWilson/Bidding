﻿namespace DataAccessLayer.DbContext
{
    using DataAccessLayer.Models;
    using Microsoft.EntityFrameworkCore;

    public class BiddingDbContext : DbContext
    {
        public BiddingDbContext(DbContextOptions<BiddingDbContext> options) : base(options)
        {
        }

        public DbSet<User> User { get; set; }
        public DbSet<AuctionItem> AuctionItem { get; set; }
        public DbSet<Bid> Bid { get; set; }
    }
}
