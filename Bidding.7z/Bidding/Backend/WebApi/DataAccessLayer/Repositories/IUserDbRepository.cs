﻿namespace DataAccessLayer.Repositories
{
    using DataAccessLayer.Models;

    public interface IUserDbRepository
    {
        User Add(User user);

        User Get(User user);
    }
}