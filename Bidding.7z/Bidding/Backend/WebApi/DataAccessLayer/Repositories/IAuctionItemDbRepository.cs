﻿namespace DataAccessLayer.Repositories
{
    using DataAccessLayer.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq.Expressions;

    public interface IAuctionItemDbRepository
    {
        AuctionItem Add(AuctionItem item);

        IEnumerable<AuctionItem> GetAllItemsOfUser(int userId);

        IEnumerable<AuctionItem> GetAllItemsOfOthers(int userId);

        AuctionItem Get(int id);

        AuctionItem Update(AuctionItem patchedItem);

        AuctionItem Delete(int id, int userId);
    }
}
