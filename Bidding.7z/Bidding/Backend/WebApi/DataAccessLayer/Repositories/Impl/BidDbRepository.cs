﻿namespace DataAccessLayer.Repositories
{
    using DataAccessLayer.DbContext;
    using DataAccessLayer.Models;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Generic;
    using System.Linq;

    public class BidDbRepository : IBidDbRepository
    {
        private readonly BiddingDbContext _dbContext;

        public BidDbRepository(BiddingDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public Bid Add(Bid bid)
        {
            _dbContext.Bid.Add(bid);
            return _dbContext.SaveChanges() > 0 ? bid : null;
        }

        public IEnumerable<Bid> GetBids(int auctionItemId)
        {
            return _dbContext.Bid
                .Include(x => x.User)
                .Include(x => x.AuctionItem)
                .OrderByDescending(x => x.Price)
                .AsNoTracking().Where(x => x.AuctionItemId == auctionItemId);
        }
    }
}
