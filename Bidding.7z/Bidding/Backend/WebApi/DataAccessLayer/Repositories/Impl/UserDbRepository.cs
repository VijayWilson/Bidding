﻿namespace DataAccessLayer.Repositories
{
    using DataAccessLayer.DbContext;
    using DataAccessLayer.Models;
    using System.Linq;

    public class UserDbRepository : IUserDbRepository
    {
        private BiddingDbContext _dbContext;

        public UserDbRepository(BiddingDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public User Add(User user)
        {
            var entity = _dbContext.User.Add(user);
            return _dbContext.SaveChanges() > 0 ? entity.Entity : null;
        }

        public User Get(User user)
        {
            return _dbContext.User.FirstOrDefault(u => u.Email == user.Email && u.Password == user.Password);
        }
    }
}
