﻿namespace DataAccessLayer.Repositories
{
    using DataAccessLayer.DbContext;
    using DataAccessLayer.Models;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;

    public class AuctionItemDbRepository : IAuctionItemDbRepository
    {
        private readonly BiddingDbContext _dbContext;

        public AuctionItemDbRepository(BiddingDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public AuctionItem Add(AuctionItem item)
        {
            var entity = _dbContext.AuctionItem.Add(item);
            return _dbContext.SaveChanges() > 0 ? entity.Entity : null;
        }

        public IEnumerable<AuctionItem> GetAllItemsOfUser(int userId)
        {
            return _dbContext.AuctionItem
                    .Include(x => x.Bids.OrderByDescending(y => y.Price))
                    .Where(x => x.UserId == userId)
                    .AsNoTracking();
        }

        public IEnumerable<AuctionItem> GetAllItemsOfOthers(int userId)
        {
            return _dbContext.AuctionItem
                    .Include(x => x.Bids.OrderByDescending(y => y.Price))
                    .Where(x => x.UserId != userId)
                    .Where(x => x.EndDate > DateTime.UtcNow)
                    .AsNoTracking();
        }

        public AuctionItem Get(int id)
        {
            return _dbContext.AuctionItem
                    .Include(x => x.Bids.OrderByDescending(y => y.Price))
                    .AsNoTracking()
                    .FirstOrDefault(x => x.Id == id);
        }

        public AuctionItem Update(AuctionItem patchedItem)
        {
            _dbContext.Update(patchedItem);

            return _dbContext.SaveChanges() > 0 ? Get(patchedItem.Id) : null;
        }

        public AuctionItem Delete(int id, int userId)
        {
            var entity = _dbContext.AuctionItem.AsNoTracking().FirstOrDefault(x => x.Id == id && x.UserId == userId);
            if (entity != null)
            {
                _dbContext.AuctionItem.Remove(entity);
                return _dbContext.SaveChanges() > 0 ? entity : null;
            }
            return null;
        }
    }
}
