﻿
namespace DataAccessLayer.Repositories
{
    using DataAccessLayer.Models;
    using System.Collections.Generic;

    public interface IBidDbRepository
    {
        Bid Add(Bid bid);

        IEnumerable<Bid> GetBids(int auctionItemId);
    }
}
